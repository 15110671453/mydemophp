<?php
require '../ThinkPHP/ThinkPHP.php';