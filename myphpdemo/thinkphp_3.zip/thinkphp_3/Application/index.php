<?php
//创建多个应用 多个应用都有自己的index.php 都要引入
//把tp框架的核心程序引入到当前项目
// 引入ThinkPHP入口文件
require '../ThinkPHP/ThinkPHP.php';
