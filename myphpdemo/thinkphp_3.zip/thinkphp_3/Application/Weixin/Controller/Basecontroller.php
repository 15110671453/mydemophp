<?php
/*微信开发的公共类 不含支付 如需要自行导入*/
namespace Weixin\Controller;
use Think\Controller;
use 