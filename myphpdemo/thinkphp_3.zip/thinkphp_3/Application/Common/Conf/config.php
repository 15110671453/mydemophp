<?php
return array(
	//'配置项'=>'配置值'
		'APP_GROUP_LIST' => 'Home,Admin', //项目分组设定
		'DEFAULT_GROUP'  => 'Home', //默认分组
		'URL_MODEL'	=>	2, // 如果你的环境不支持PATHINFO 请设置为3
		'DB_TYPE'	=>	'mysql',
		'DB_HOST'	=>	'localhost',
		'DB_NAME'	=>	'examples',
		'DB_USER'	=>	'root',
		'DB_PWD'	=>	'123456',
		'DB_PORT'	=>	'3306',
);