<?php
//php是对大小写敏感的
$color ="red";
echo "My car is".$color."<br>";
echo "My house is".$Color."<br>";
