<?php
return array(
	//'配置项'=>'配置值'
	 'URL_MODEL'             =>  1,
);