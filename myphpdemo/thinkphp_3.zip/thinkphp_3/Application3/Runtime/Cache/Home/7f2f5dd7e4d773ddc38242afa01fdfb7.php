<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Insert title here</title>
</head>
<body>
	
	<div style = "width:500px ;height:400px;border:10px red solid ;">
	 <img src = "icon.png" width = "40px"/>
	</div>
</body>
</html>